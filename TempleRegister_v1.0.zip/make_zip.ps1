Add-Type -AssemblyName System.IO.Compression.FileSystem

$projectDir = (Get-Location).Path
$targetZip = Join-Path $projectDir "TempleRegister_v1.0.zip"
$desktopZip = "C:\Users\support\OneDrive\Desktop\TempleRegister_v1.0.zip"
$tmpDir = Join-Path $env:TEMP ("TemplePkg_" + [System.Guid]::NewGuid().ToString("N"))

New-Item -ItemType Directory -Path $tmpDir -Force | Out-Null

Get-ChildItem -Path $projectDir -Exclude ".git", "*.zip" | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $tmpDir -Recurse -Force
}

if (Test-Path $targetZip) { Remove-Item $targetZip -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($tmpDir, $targetZip)

Copy-Item -Path $targetZip -Destination $desktopZip -Force
Remove-Item $tmpDir -Recurse -Force

Get-Item $targetZip, $desktopZip | Select-Object FullName, Length, LastWriteTime
